package lab11_1;
import java.util.ArrayList;

public class MusicBox implements SimpleQueue {
         private ArrayList<String> playlist = new ArrayList<>();
        
         public void enqueue(Object o) {
                  playlist.add(o.toString());
                  System.out.println(o+" is added in queue");
         }

         public void dequeue() {
                  System.out.println("Now playing "+playlist.get(0));
                  playlist.remove(0);
         }
    
}
