package lab11_1;
import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue {
    private ArrayList<Product> listProduct = new ArrayList<>();
    double total;
    public void enqueue(Object o) {
        listProduct.add((Product) o);
        System.out.println(((Product)o).getName()+" is added in queue");
    }

    public void dequeue() {
        total=total+(listProduct.get(0)).getPrice();
        listProduct.remove(listProduct.get(0));
    }
    
    public double getAmount(){
        return total;
    }
}

