package lab10_1;

public class Subject implements Evalution {
         private String subjName;   //เก็บชื่อวิชาที่จะรับการประเมินว่า คะแนนเฉลี่ยของนิสิตทั้งห้องผ่านมาตรฐานที่กำหนดหรือไม
         private int[] score;   //อาร์เรย์เก็บคะแนนของนิสิตทุกคนในห้อง คะแนนเต็ม 100 คะแนน
    
         public Subject(String subjectName, int[] score){
                  this.subjName = subjectName;
                  this.score = score;
         }
    
         @Override
         public double evaluate(){
                  int total=0;
                  for(int i=0 ; i<score.length ; i++){
                           total+=score[i];
                  }
                  double average = total/score.length;
                  return average ;
         }
    
         @Override
         public char grade(double scr){     //รับค่าพารามิเตอร์คือ คะแนนเฉลี่ยที่ได้จากเมธอด evaluate()
                  scr = evaluate();
                  if(scr >= 70){        
                           return 'P' ;      //70 คะแนนขึ้นไป ให้ส่งค่าคืนเป็นอักขระ ‘P’ แปลว่า การสอนผ่านมาตรฐาน
                  }
                  else{
                           return 'F' ;      //น้อยกว่า 70 คะแนน ให้ส่งค่าคืนเป็นอักขระ ‘F’ แปลว่า การสอนไม่ได้มาตรฐาน
                  }
         }
    
         @Override
         public String toString(){
                  return subjName ;
         }
    
}
