package lab10_1;

public interface Evalution {
         double evaluate();
         char grade(double scr);

}
