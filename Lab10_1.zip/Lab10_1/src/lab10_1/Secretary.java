package lab10_1;

public class Secretary extends Employee implements Evalution {
         private int typingSpeed;
         private int[] score;
    
         public Secretary(String name ,int salary ,int[] score ,int typingSpeed){
                  super(name,salary) ;
                  this.score = score ;
                  this.typingSpeed = typingSpeed ;
         }
    
         @Override
         public double evaluate(){  //ให้วนลูปหาคะแนนรวมของคะแนนสอบในอาร์เรย์แล้วส่งคืนค่าคะแนนรวม
                  int total=0;
                  for(int i=0 ; i<score.length ; i++){
                           total+=score[i];
                  }
                  return total ;
         }
    
         @Override
         public char grade(double scr){   //รับค่าพารามิเตอร์คือ คะแนนรวมที่ได้จาก method evaluate() 
                  scr = evaluate();
                  if(scr >= 90) {
                           setSalary(18000);    //กำหนดค่าเงินเดือนให้มีค่าเป็น 18000
                           return 'P' ;                 //ส่งค่าคืนเป็นอักขระ ‘P’ แปลว่า รับเข้าทำงาน
                  }
                  else 
                           return 'F' ;
         }
    
}
