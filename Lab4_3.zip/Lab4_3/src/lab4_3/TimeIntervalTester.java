package lab4_3;
import java.util.Scanner;

public class TimeIntervalTester {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int startTime = sc.nextInt();
        System.out.print("\nEnter end time: ");
        int endTime = sc.nextInt();
        TimeInterval reg1 = new TimeInterval(startTime,endTime);
        System.out.println( reg1.getHours() +" hours "+ reg1.getMinutes() +" minutes" );
    }
    
}
