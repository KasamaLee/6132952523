package lab4_3;

public class TimeInterval {
    private int startTime;
    private int endTime;
    private int hours;
    private int minutes;
    private final int totalMinutes;
    
    public TimeInterval(int startTime,int endTime) {
        this.startTime = startTime;
        this.endTime = endTime; 
        totalMinutes = ( (endTime/100 - startTime/100) *60 ) + (endTime%100 - startTime%100);
      //totalMinutes = (convert hours to minutes)            + (minutes)
    }
    
    public int getHours() {
        hours = totalMinutes/60;
        return hours;
    }
    
    public int getMinutes() {
        minutes = totalMinutes%60;
        return minutes;
    }
    
}
