
package lab3_1;

public class InsectPopulation {
    public double num;
    //public double breed;
    //public double spray;
    
    public InsectPopulation(double n){
        num = n;
    }

    
    public void breed()  {
        num = num*2;
    }
    
    public void spray()  {
        num = num*0.9;
    }

    public double getNumInsect(){
        return num;
        
    }
}
