
package lab3_1;
//import java.util.Scanner; don't use scanner


public class InsectPopulationTester {
     public static void main(String[] args) {
        InsectPopulation o1 = new InsectPopulation(10);
        o1.breed();
        o1.spray();
        System.out.println("Number of insects: " + o1.getNumInsect());
        o1.breed();
        o1.spray();
        System.out.println("Number of insects: " + o1.getNumInsect());
        o1.breed();
        o1.spray();
        System.out.println("Number of insects: " + o1.getNumInsect());

    }
    

}
