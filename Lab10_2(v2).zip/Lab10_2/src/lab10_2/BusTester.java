package lab10_2;
import java.util.ArrayList;

public class BusTester {

    public static void main(String[] args) {
         ArrayList<Bus> arr = new ArrayList<>();
         Hybrid h1 = new Hybrid(45, 1.2E6, Electric.HIGH_VOLTAGE, 150.0, 1);
         CNGBus cng1 = new CNGBus(50, 1E6, 200, 2);

         arr.add(h1);
         arr.add(cng1);

         for (Bus bus : arr) {
                  System.out.print("ID: ");
                  System.out.println(bus.getID());
                  System.out.print("Emission Tier: ");
                 
                  if (bus instanceof CNGBus) {
                           System.out.println(((CNGBus) bus).getEmissionTier());
                  }
                  else if (bus instanceof Hybrid) {
                           System.out.println(((Hybrid) bus).getEmissionTier());
                  }
                  System.out.print("Accel: ");
                  System.out.println(bus.getAccel());
         }
    }
    
}
