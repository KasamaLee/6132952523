
package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class CalendarTester {
 
    public static void main(String[] args) {
        //GregorianCalendar cal = new GregorianCalendar(2019,Calendar.JANUARY, 8);
        //System.out.println(cal);    
        
        GregorianCalendar cal = new GregorianCalendar();
        cal.add(Calendar.DAY_OF_MONTH, 100);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH)+1;
        int year = cal.get(Calendar.YEAR);
        System.out.println(weekday + " " + dayOfMonth + " " + month + " " + year);
        
        //GregorianCalendar bday = new GregorianCalendar(1990,Calendar.MARCH,12);
        GregorianCalendar bday = new GregorianCalendar(1997,Calendar.SEPTEMBER,26);
        bday.add(Calendar.DAY_OF_MONTH, 10000);
        int weekdayB = bday.get(Calendar.DAY_OF_WEEK);
        int dayOfMonthB = bday.get(Calendar.DAY_OF_MONTH);
        int monthB = bday.get(Calendar.MONTH)+1;
        int yearB = bday.get(Calendar.YEAR);
        System.out.println(weekdayB + " " + dayOfMonthB + " " + monthB + " " + yearB);
    
    }
    
}
