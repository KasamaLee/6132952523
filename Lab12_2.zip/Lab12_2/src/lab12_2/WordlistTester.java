/*
ให้เขียน try-catch จัดการ exception เอง
hint: อ่านจากไฟล์มาเก็บไว้ใน array list ก่อน แล้วค่อยเอาไปใช้ทำงานต่อ

 */
package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class WordlistTester {

    public static void main(String[] args) {
            ArrayList<String> list = new ArrayList<>();
        ArrayList<String> sentence = new ArrayList<>();
        
        try
        {
           File file = new File("C:\\Users\\Latte\\Documents\\NetBeansProjects\\Lab12_2\\src\\lab12_2\\wordlist.txt");
           Scanner wordlist = new Scanner(file);
           while(wordlist.hasNextLine()==true)
            {
                String Word  = wordlist.nextLine();
                list.add(Word);
            }
           Scanner keyboard = new Scanner(System.in);
           System.out.print("Enter a sentence: ");
           String input = keyboard.nextLine();
           String word = "" ;
           for(int i =0 ; input.length()>i ; i++)
            {
                if(input.charAt(i)!=' ')
                {
                    word+=input.charAt(i);
                    if(i ==input.length()-1 )
                    {
                        sentence.add(word);   
                    }
                }
                else 
                { 
                    sentence.add(word.trim());
                    word ="";        
                }                                       
             }
            wordlist.close();
            int count=0;
            ArrayList<String> notContain = new ArrayList<>();
     
            for(String vocab:sentence)
            {
                boolean check =false;
                for(String listvocab : list )
                {
                    if(vocab.equals(listvocab))
                    {
                        count++;
                        check = true;
                        break;
                    }
                }
                if(check == false)notContain.add(vocab);
            }
            System.out.println("Words not contained:");
            if(count==sentence.size())
            {
                System.out.println("N/A");
            }
            else
            {
                for(String not : notContain )
                {
                    System.out.println(not);
                }
            }
        } 
        catch (FileNotFoundException ex) 
        { 
            System.out.println("Error: "+ex.getMessage());    
        }        
        catch(Exception ex)
        { 
            System.out.println("Error: "+ex.getMessage());
        }      
        
    }
    
}
