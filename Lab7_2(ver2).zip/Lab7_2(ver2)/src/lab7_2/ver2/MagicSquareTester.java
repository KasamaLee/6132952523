package lab7_2.ver2;

public class MagicSquareTester {

    public static void main(String[ ] args) {
        MagicSquare square = new MagicSquare(5);
        System.out.println(square.toString());
    }
    
}
