package lab7_2.ver2;

public class MagicSquare {
    private final Integer[ ][ ] square;
    private final int bound;
    public MagicSquare (int n)
    {
        bound = n-1;
        square = new Integer[n][n];
        
        int k = 1;
        int row = n-1;
        int column = n/2;
        
        while (k <= n*n)
        {
            if ((row == bound+1)&&(column == bound+1)) 
            {
                row -= 2;
                column -= 1;                 
            }
           else
            {
                if(row > bound){row = 0;}
                if(column > bound) {column = 0;}               
            }
            
            if (square[row][column] != null) 
            {
                row -= 2;
                column -= 1;
            }
                    
            square[row][column] = k;
            k += 1;
            row += 1;
            column += 1;           
        }           
    }
    
    
    public String toString ()
    {
        String number = "";
        for (int i = 0; i <= bound;i++)
        {
            for (int j = 0; j <= bound; j++)
            {
                number = number + square[i][j] + "\t";
            }
            number = number + "\n\n";
        }
        return number;
    }    
    
}
