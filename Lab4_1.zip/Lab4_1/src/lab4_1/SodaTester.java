package lab4_1;
import java.util.Scanner;

public class SodaTester {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter height: ");
        float height = sc.nextFloat();
        System.out.print("Enter diameter: ");
        float diameter = sc.nextFloat();
        SodaCam can1 = new SodaCam(height,diameter);

        System.out.printf("Volume: %.2f \n",can1.getVolume()); //printformat
        System.out.printf("Surface area: %.2f",can1.getSurfacearea());
    }
    
}
