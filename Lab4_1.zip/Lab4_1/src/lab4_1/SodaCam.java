package lab4_1;
import java.lang.Math;

public class SodaCam {
    private float height;
    private float diameter;
    private float r;
    private float volume;
    private float surfaceArea;
    
    public SodaCam(float height,float diameter) {
        this.height = height;
        this.diameter = diameter; 
    }
    
    public float getVolume() {
        r = (float)1/2*diameter;
        volume = height*(float)Math.pow(r,2)*(float)Math.PI;  //r**2
        return volume;
    }
    
    public float getSurfacearea() {
        //int r = (1/2)*diameter;
        surfaceArea = (height*2*r*(float)Math.PI)+2*((float)Math.pow(r,2)*(float)Math.PI);  //((2*pi*r))*h
        return surfaceArea ;
    } 
    
}
