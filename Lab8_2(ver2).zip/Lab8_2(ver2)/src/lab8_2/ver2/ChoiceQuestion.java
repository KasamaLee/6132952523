package lab8_2.ver2;
import java.util.ArrayList;

public class ChoiceQuestion extends Question {
    private ArrayList<String> choices ;
   
   public ChoiceQuestion(String text){
       super(text);
       choices = new ArrayList<>();
   }
   
   public void addChoice(String choice, boolean correct){
       choices.add(choice);
       if (correct) setAnswer(choice);
   }
   
   @Override
   public void display(){
       System.out.println(getText());
       int i = 1;
       for (String c : choices){
           System.out.println(i+":"+c);
           i++;
       }
   }
   
   @Override
   public boolean checkAnswer(String response){
      int index = Integer.parseInt(response)-1;
      return choices.get(index).equals(getAnswer());
   }
    
}
