package lab8_2.ver2;

public class NumericQuestion extends Question {
    public NumericQuestion(String text){
        super(text);
    }
    
    @Override
    public boolean checkAnswer(String response){
        double numRes = Double.parseDouble(response);
        double numAns = Double.parseDouble(getAnswer());
        return (numRes-numAns)<=0.01 || (numAns-numRes)<=0.01;
    }
    
}
