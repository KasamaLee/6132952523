
package lab3_2;

public class LetterTester {
    public static void main(String[] args)
    {
        Letter message1 = new Letter("Jade","Clarissa"); //(String from, String to)
        message1.addLine("We must find Simon quickly.");
        message1.addLine("He might be in danger.");
        System.out.println("Dear "+message1.getText());

    }
    
}
