
package lab3_2;


public class Letter {
    private String message = ""; //empty String for input String from Tester class
    private String sender;
    private String receiver;
    
    
    public Letter(String from, String to){  //construtor for input String through parameter
        sender = from ; //input String into sender variable
        receiver = to ;
    }
    public void addLine(String line){
        message = message + line + "\n"  ;
    }
    public String getText(){
        return sender +":"+"\n"+"\n"+ message +"\n"+"Sincerely,"+"\n"+"\n"+ receiver;
    }
    
    
}
