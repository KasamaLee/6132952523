package lab3_3;

public class CashRegisterTester {
        public static void main(String[] args) {
        CashRegister reg1 = new CashRegister(7); //receive 7 through Constructor
        reg1.setPurchase(50.0);
        reg1.setPurchase(10.0);
        reg1.recordTaxablePurchase(20.0);
        reg1.setPayment(100.0);
            //System.out.println(reg1.getTotalTax());
        System.out.printf("Your change is %.1f \n" , reg1.giveChange() );
    
    }
    
}
