package lab3_3;

public class CashRegister {
    private double payment;     //these value are empty
    private double value;
    private double change;
    private double tax;
    private final double percentTax;
    
    public CashRegister(double percentTax){ //Constructor
        this.percentTax = percentTax/100;
    }
    
    public void setPurchase(double product) {
        value += product;    //add amount into the value
                            //now, the value variable is not emty
        //System.out.println(value);                   
    }
    
    public void recordTaxablePurchase(double productWithTax){
        value += productWithTax*percentTax;
        double taxValue = productWithTax-(productWithTax*percentTax);
        tax += taxValue;
        value += productWithTax;
    }
    
     public void setPayment(double paid) {  //accept value through parameter
        payment += paid;    //add amount into the payment that is variable
        //System.out.println(payment);
    }
     
     public double getTotalTax(){
        return tax;
    }
     
     public double giveChange() {      // don't receive parameter 
        change = payment - value; 
        //percentTax = 0;
        value = 0;
        tax = 0;
        payment = 0;
        return change;
        //System.out.println(change);
    }
    /*
    public void displayer() {
        System.out.println(value); 
        System.out.println(payment); 
        System.out.println(change);
    }
    */
    
}
