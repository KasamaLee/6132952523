/*
หมายเหตุ การทดสอบโปรแกรม ขอให้พิมพ์ข้อความที่เว้นวรรคด้วยการเคาะ 1 space เท่านั้น และการนับตัว
อักขระ จะนับเฉพาะ space ไม่นับรวม ‘\n’
ไม่ต้องเขียนจัดการ exception เอง แค่ประกาศไว้ก็พอ
 */
package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class SequentialTextFile {

    public static void main(String[] args) throws FileNotFoundException {
         File file = new File("input.txt");
         Scanner sc = new Scanner(System.in);
         PrintWriter write = new PrintWriter(file);
         String in = sc.nextLine();
         while(!in.equals("quit")){
            write.print(in+"\n");
            in = sc.nextLine();
         }
         write.close();
         Scanner read = new Scanner(file);
         int charCnt = 0;
         int wordCnt = 0;
         int lineCnt = 0;
         while(read.hasNextLine()){
            String line = read.nextLine();
            lineCnt++;
            String[] words = line.split(" ");
            wordCnt += words.length;
            charCnt += line.length();
         }
         System.out.println("Total characters : "+charCnt);
         System.out.println("Total  words : "+ wordCnt);
         System.out.println("Total lines : "+lineCnt);
    }
        
}
