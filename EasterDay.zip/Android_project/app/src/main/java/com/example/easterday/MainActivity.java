package com.example.easterday;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.content.Intent ;
import android.widget.EditText;
import android.widget.Button;

public class MainActivity extends Activity {
    public static final String EXTRA_MESSAGE = "com.example.easterday.MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText txtName = (EditText) findViewById(R.id.editText1);
        final Button subMitfrm = (Button) findViewById(R.id.button);
        subMitfrm.setOnClickListener((v) -> {
                    if (txtName.getText().toString().trim().equals(""))
                        txtName.setError("Please enter year!!");
                    else {
                        EasterDay easter = new EasterDay(Integer.parseInt(txtName.getText().toString()));
                        easter.calculation();
                        Intent i = new Intent(getApplicationContext(), Main2Activity.class);
                        i.putExtra("day", String.valueOf(easter.getDay()));
                        i.putExtra("month", String.valueOf(easter.getYear()));
                        startActivity(i);
                    }
                }
        );
    }

    public void sendMessage(View view) {
        Intent intent = new Intent(this, Main2Activity.class);
        EditText editText = (EditText) findViewById(R.id.editText1);
        String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }
}
