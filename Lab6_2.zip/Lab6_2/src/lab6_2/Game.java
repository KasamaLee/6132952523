package lab6_2;
import java.util.Random;
import java.util.Scanner;

public class Game {
    private int playerScore;
    private int comScore;
    private final int rock=0;
    private final int paper=1;
    private final int scissors=2;
    
    public void play(){
        Scanner in = new Scanner(System.in);
        Random rd = new Random();
        int check;
        String ip = null;
        this.comScore = 0;
        int myScore = 0;
        while(true)
        {
            check = 1;
            while(check == 1)
            {
                System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
                ip=in.next();
                switch(ip)
                {
                    case "0": System.out.println("You enter: ROCK"); check = 0; break;
                    case "1": System.out.println("You enter: PAPER"); check = 0; break;
                    case "2": System.out.println("You enter: SCISSORS"); check = 0; break;
                }
            }
            switch(rd.nextInt(3))
            {
                case 0: System.out.println("Computer: ROCK"); ip+="0"; break;
                case 1: System.out.println("Computer: PAPER"); ip+="1"; break;
                case 2: System.out.println("Computer: SCISSORS"); ip+="2"; break;
            }
            if(ip.equals("00") || ip.equals("11") || ip.equals("22"))
            {
                System.out.println("It's a tie");
            }
            else if(ip.equals("02") || ip.equals("10") || ip.equals("21"))
            {
                myScore+=1;
                System.out.println("You win!");
            }
            else
            {
                comScore+=1;
                System.out.println("You lose!");
            }
            if(myScore-comScore == 2 || myScore-comScore == -2)
            {
                System.out.println("\n----------------------------------------\n");
                if(myScore-comScore == 2)
                {
                    System.out.println("Congrats! You win.");
                }
                else if(myScore-comScore == -2)
                {
                    System.out.println("Too bad! You lose");
                }
                System.out.println("User Score: "+myScore);
                System.out.println("Computer score: " + comScore);
                break;
            }
        }
    }
}
