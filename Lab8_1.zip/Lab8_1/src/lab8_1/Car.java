package lab8_1;

public class Car {
    protected double gas ;
    protected double efficiency ;
    
    public Car(double gas , double efficiency){
        this.gas = gas ;
        this.efficiency = efficiency ;  
    }
    
    public void setGas(double amount){ //เพื่อกำหนดค่าจำนวนน้ำมันในถัง
        this.gas = amount ;
    }
    
    public double getGas(){ //เพื่อคืนค่าจำนวนน้ำมันในถัง
        return this.gas ;
    }
    
    public double getEfficiency(){ //เพื่อคืนค่าอัตราการใช้น้ำมัน
        return efficiency ;
    }
    
    public void drive(double distance){
        double usedGas = distance/efficiency ; 
        
        if (usedGas>gas) {
            System.out.println("You cannot drive too far, please add gas");
        }
        else {
            this.gas -= usedGas ;
        }
    }
    
    public void addGas(double amount){  //เพื่อเพิ่มน้ำมันในถัง
        this.gas += amount ;
    }   
    
}
