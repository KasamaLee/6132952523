package lab9_1;
import java.util.ArrayList;

public class Order {
         public static int cntOrder = 0; //ตัวนี้เอาไว้ auto generate id ของใบ order
         private int id;
         private Customer c;
         private ArrayList<Pizza> p;
         
         public Order( Customer c ) {
                  p = new ArrayList<>();
                  this.id = cntOrder+1 ;
                  this.c = c ;
         }
         
         public void addPizza(Pizza piz){
                  p.add(piz);
         }
         
         public String getOrderDetail() {
                  String details = "" ;
                  for (Pizza i : p) {
                           details += i.toString()+"\n";
                  }
                  cntOrder++;
                  
                  return "Order id : "+id+"\n"
                             +c.toString()
                             +"\n"+details+"Total pieces : "+p.size()
                             +"\nTotal cost : "+this.calculatePayment(); 
         }
         
         public double calculatePayment() {
                  double allPrice = 0;
                 
                  for (int i=0;i<=p.size()-1;i++) {
                           allPrice+=(p.get(i)).getPrice();
                  }
                  
                  if(c instanceof GoldCustomer) {
                           allPrice=allPrice*(100-((GoldCustomer)c).getDiscount())/100;
                  }
                  return allPrice;
         }
    
}
