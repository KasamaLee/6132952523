
package lab2_2;

public class HollePrintor {

    public static void main(String[] args) {
        String w = "Hello, World!";
        String w2 = w.replace("o","e");
        String w3 = w2.replace("He","Ho");
        //System.out.println(w2);
        System.out.println(w3);
        
    }
    
}
