package lab5_1;

public class Zeller {
    private static int dayOfMonth;
    private static int month;
    private static int year;
    private static int h,q,m,j,k ;
    
    public Zeller(int d,int m,int y)
    {
        dayOfMonth = d;
        month = m;
        year = y;
    }
    public enum Day {
        SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),THURSDAY("Thursday"),FRIDAY("Friday"),SATURDAY("Saturday");
        public final String dayOfWeek;
        private Day(String day)
        {
            this.dayOfWeek = day;
        }
        
        public static Day getDayOfWeek()
        {
            q = dayOfMonth;
            m = month;
            if (m==1)
            {
                year = year - 1 ;
                m = 13;
            }
            if (m==2)
            {
                year = year - 1 ;
                m = 14;
            }
            j = year/100;
            k = year%100;
            h = (q+(((26*(m+1))/10)+k+(k/4)+(j/4)+(5*j)))%7;
            Day dayWord = Day.SUNDAY;
            switch (h) {
                case 0: dayWord = Day.SATURDAY; break;
                case 1: dayWord = Day.SUNDAY; break;
                case 2: dayWord = Day.MONDAY; break;
                case 3: dayWord = Day.TUESDAY; break;
                case 4: dayWord = Day.WEDNESDAY; break;
                case 5: dayWord = Day.THURSDAY; break;
                case 6: dayWord = Day.FRIDAY; break;
                default: break;
            }
            return dayWord;
        }
    }
    
}
