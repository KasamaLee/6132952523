
package lab5_1;
import java.util.Scanner;
import lab5_1.Zeller.Day;

public class ZellerTester {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter year (e.g,2012): ");
        int years = sc.nextInt();
        System.out.print("Enter month (1-12): ");
        int months = sc.nextInt();
        System.out.print("Enter day of month (1-31): ");
        int days = sc.nextInt();
        Zeller zeller = new Zeller(days,months,years);
        Day tester = Day.getDayOfWeek();
        System.out.println("Day of the week is "+tester.dayOfWeek);
    }
    
}
