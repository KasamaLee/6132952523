/*

 */
package lab12_3;

public class TransactionRecord {
    private int acctNo;
    private double trans;
    public TransactionRecord(int acctNo,double trans){
        this.acctNo = acctNo;
        this.trans = trans;
    }
    public double getAcctNo(){
        return acctNo;
    }
    public double getTrans(){
        return trans;
    }
    
}
