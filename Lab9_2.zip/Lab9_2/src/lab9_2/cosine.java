package lab9_2;

public class cosine extends Taylor {
         private double ans;
         
         public cosine(int k,double x){
                  super.setIter(k);
                  super.setValue(x);
         }

         @Override
         public void printValue() {
                  for ( int n = 0 ; n <= super.getIter() ; n++ ) {
                           this.ans += (Math.pow(-1, n)*Math.pow(super.getValue(),2*n))/(super.factorial(2*n)) ;
                  }
         System.out.println("Value form Math.cos() is "+getApprox()+".");
         System.out.println("Approximated value is "+ans+".");
         }

         @Override
         public double getApprox() {
                  return Math.cos(super.getValue()) ;
         }
    
}
