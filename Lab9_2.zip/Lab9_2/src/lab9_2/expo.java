package lab9_2;

public class expo extends Taylor {
         public expo( int k , double x ) {
                  super.setIter(k);
                  super.setValue(x);
         }
         
         @Override
         public void printValue() {
                  double ans = 0;
                  for(int n = 0;n <= super.getIter();n++){
                           ans += (Math.pow(super.getValue(),n))/super.factorial(n);
                  }
                  
                  System.out.println("Value form Math.exp() is "+getApprox()+".");
                  System.out.println("Approximated value is "+ans+".");
         }

         @Override
         public double getApprox() {
                  return Math.exp(super.getValue()) ;
         }
    
}
