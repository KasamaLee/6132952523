package lab4_2;

public class DigitExtractor {
    private int digit;
    private int num;
    private int anInteger;
    
    public DigitExtractor(int num) {
        anInteger = num;
    }
    
    public int nextDigit() {
        digit = anInteger%10;
        anInteger = anInteger/10;
        return digit;
    }
    
}
