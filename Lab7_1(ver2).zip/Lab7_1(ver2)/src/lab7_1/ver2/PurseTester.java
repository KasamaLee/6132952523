
package lab7_1.ver2;

public class PurseTester {

    public static void main(String[] args) {
        Purse aBag = new Purse();       
        aBag.addCoin("Quarter");
        aBag.addCoin("Dime");
        aBag.addCoin("Nickel");
        aBag.addCoin("Dime");      
        System.out.println("purseA: "+aBag.toString());
        System.out.println("reversed PurseA: "+aBag.reverse());
        
        Purse bBag = new Purse();
        bBag.addCoin("Quarter");
        System.out.println("purseB: "+bBag);
        
        aBag.transfer(bBag);
        System.out.println("purseA after transfer: "+aBag);
        System.out.println("purseB after transfer: "+bBag);
        
        Purse cBag = new Purse();
        cBag.addCoin("Quarter");
        cBag.addCoin("Dime");
        cBag.addCoin("Nickel");
        
        Purse dBag = new Purse();
        dBag.addCoin("Quarter");
        dBag.addCoin("Nickel");
        dBag.addCoin("Dime");
        
        System.out.println("purseC: "+cBag);
        System.out.println("purseD: "+dBag);
        System.out.println("purseC is the same coins as purseD?: " + cBag.sameContents(dBag));
        System.out.println("purseC is the same coins as purseD?: " + cBag.sameCoins(dBag));
    }
     
 }
    

